package p1.cinema.ingCinema;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IngCinemaApplication {

	public static void main(String[] args) {
		SpringApplication.run(IngCinemaApplication.class, args);
	}

}
